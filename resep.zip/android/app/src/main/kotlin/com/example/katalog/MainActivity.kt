package com.example.katalog

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
